RYL TOURNAMENT ZONE BD — TWO SEPARATE APPS
===========================================

এই প্যাকেজে একই Firebase project (ryl-f470d) ব্যবহার করে দুটি আলাদা installable Web App/PWA আছে:

1) player-app/ — Player interface only
2) admin-app/  — Admin interface only

Player app-এ Admin dashboard নেই। Admin app-এ Player app-এর screen নেই।
Admin login-এ আগের Firebase Authentication + admins/{uid} role check অক্ষত আছে।
Player/Admin উভয় অ্যাপ একই Firebase Auth ও Firestore project ব্যবহার করে।

গুরুত্বপূর্ণ:
- এটি দুটি আলাদা PWA/Web App build; APK ফাইল এই ZIP-এ নেই।
- Android-এ HTTPS Hosting URL Chrome দিয়ে খুলে Install app / Add to Home screen করলে আলাদা আলাদা app হিসেবে ইনস্টল হবে।
- APK বানানোর পরের ধাপে এই দুই web app-কে Android wrapper-এ প্যাকেজ করতে হবে।
- Firebase client config browser-এ থাকা স্বাভাবিক; নিরাপত্তা Firestore Rules এবং Admin role check দিয়ে enforce করতে হবে।
- Firebase Rules পরিবর্তন না করে বিদ্যমান rules deploy করা হবে। নতুন Admin যোগ করতে আগের setup guide-এর নির্দেশনা অনুসরণ করুন।

Firebase Hosting deploy (Firebase CLI প্রয়োজন)
------------------------------------------------
Project root-এ terminal খুলে:

1. Firebase-এ দুটি Hosting site তৈরি করুন (site ID আগে থেকে ব্যবহৃত হলে নতুন unique ID নিন):
   firebase hosting:sites:create ryl-tournament-zone-player --project ryl-f470d
   firebase hosting:sites:create ryl-tournament-zone-admin --project ryl-f470d

2. Hosting target bind করুন:
   firebase target:apply hosting player ryl-tournament-zone-player --project ryl-f470d
   firebase target:apply hosting admin ryl-tournament-zone-admin --project ryl-f470d

3. একই Firebase project-এ দুটি app ও Firestore rules deploy করুন:
   firebase deploy --only hosting:player,hosting:admin,firestore:rules --project ryl-f470d

Deploy শেষে Firebase দুটি আলাদা HTTPS URL দেবে। Player URL Player-দের এবং Admin URL শুধু Admin-দের দিন।

ইনস্টল:
- Android Chrome-এ সংশ্লিষ্ট HTTPS URL খুলুন।
- Browser menu থেকে Install app / Add to Home screen চাপুন।
- Player ও Admin আলাদাভাবে ইনস্টল করুন।

ফাইল:
- player-app/index.html — Player app
- admin-app/index.html — Admin app
- firestore.rules — একই shared Firestore security rules
- firebase.json / .firebaserc — দুই Hosting target config

পরীক্ষা:
- HTML source ও PWA manifest/service worker তৈরি করা হয়েছে।
- Live Firebase login, payment request বা hosting deployment এই পরিবেশে চালানো হয়নি।
